package com.example.ishani.login;

/**
 * Created by ishani on 19-10-2016.
 */
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends Activity {
    private int request_Code = 1;
    TextView txt;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activty_two);
        Bundle bundle = getIntent().getExtras();
        txt = (TextView) findViewById(R.id.txt);
        /*txt.setText(bundle.getString("value1"));*/
    }



            }
